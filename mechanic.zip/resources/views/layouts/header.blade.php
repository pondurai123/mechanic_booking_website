    <header class="main-header">
        <div class="header-container">
            <div class="logo">
                <i class="fas fa-snowflake"></i>
                <div class="logo-text">
                    <h1>AC Repair Chennai</h1>
                    <p>24/7 Professional Service</p>
                </div>
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="#"><i class="fas fa-home"></i> Home</a></li>
                <li class="nav-item"><a href="#"><i class="fas fa-wrench"></i> Services</a></li>
                <li class="nav-item"><a href="#"><i class="fas fa-phone"></i> Contact</a></li>
            </ul>
        </div>
    </header>