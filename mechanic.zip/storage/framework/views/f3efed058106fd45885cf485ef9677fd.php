<?php $__env->startSection('title', 'Manage Mechanics'); ?>

<?php $__env->startSection('content'); ?>
<div class="header">
    <h1><i class="fas fa-user-cog"></i> Manage Mechanics</h1>
    <a href="<?php echo e(route('admin.mechanics.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add New Mechanic
    </a>
</div>

<div class="content-card">
    <div class="card-header">
        <h3><i class="fas fa-users"></i> Active Mechanics</h3>
    </div>
    <div class="card-body">
        <?php if($mechanics->count() > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mechanics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mechanic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($mechanic->name); ?></td>
                        <td><?php echo e($mechanic->phone); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.mechanics.edit', $mechanic->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <form action="<?php echo e(route('admin.mechanics.destroy', $mechanic->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Deactivate this mechanic?')">
                                    <i class="fas fa-trash"></i> Deactivate
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No active mechanics found.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/mechanic_booking_website/resources/views/admin/mechanics/index.blade.php ENDPATH**/ ?>