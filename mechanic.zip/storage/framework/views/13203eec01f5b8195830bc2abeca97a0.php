<?php $__env->startSection('title', 'Pending Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="header">
    <h1><i class="fas fa-clock"></i> Pending Orders</h1>
    <p>Orders waiting for your approval</p>
</div>

<div class="content-card">
    <div class="card-header">
        <h3><i class="fas fa-list"></i> Pending Bookings (<?php echo e($bookings->total()); ?>)</h3>
    </div>
    <div class="card-body">
        <?php if($bookings->count() > 0): ?>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Customer</th>
                            <th>Contact</th>
                            <th>Service</th>
                            <th>Location</th>
                            <th>Preferred Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($booking->created_at->format('M d, Y')); ?></td>
                            <td>
                                <strong><?php echo e($booking->name); ?></strong><br>
                                <small style="color: #666;"><?php echo e($booking->email); ?></small>
                            </td>
                            <td>
                                <strong><?php echo e($booking->phone); ?></strong>
                            </td>
                            <td>
                                <span style="background: #e3f2fd; color: #1565c0; padding: 4px 8px; border-radius: 12px; font-size: 0.8rem;">
                                    <?php echo e($booking->service ? ucfirst(str_replace('-', ' ', $booking->service)) : 'AC Service'); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($booking->location): ?>
                                    <a href="javascript:void(0)" 
                                       onclick="openLocation('<?php echo e(addslashes($booking->location)); ?>')" 
                                       class="location-link" 
                                       title="Click to open in Google Maps">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <?php echo e(Str::limit($booking->location, 25)); ?>

                                    </a>
                                <?php else: ?>
                                    <span style="color: #999; font-style: italic;">
                                        <i class="fas fa-map-marker"></i> Not provided
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($booking->preferred_date): ?>
                                    <span style="color: #28a745; font-weight: 600;">
                                        <i class="fas fa-calendar-check"></i>
                                        <?php echo e($booking->preferred_date->format('M d, Y')); ?>

                                    </span>
                                <?php else: ?>
                                    <span style="color: #999; font-style: italic;">
                                        <i class="fas fa-calendar"></i> Flexible
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo e($booking->status); ?>">
                                    <i class="fas fa-clock"></i> <?php echo e(ucfirst($booking->status)); ?>

                                </span>
                            </td>
                            <td>
                                <div style="display: flex; flex-wrap: wrap; gap: 5px;">
                                    <button class="btn btn-info" onclick="viewOrderDetails(<?php echo e($booking->id); ?>)" title="View Details">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    
                                    <form method="POST" action="<?php echo e(route('admin.booking.approve', $booking->id)); ?>" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-success" onclick="showApproveModal(<?php echo e($booking->id); ?>)" title="Approve Booking">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                    </form>
                                    
                                    <form method="POST" action="<?php echo e(route('admin.booking.status', $booking->id)); ?>" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="cancelled">
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Cancel this booking?')" title="Cancel Booking">
                                            <i class="fas fa-times"></i> Cancel
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <tr style="background: #f8f9fa;">
                            <td colspan="8" style="font-size: 0.9rem; padding: 15px;">
                                <div style="display: grid; grid-template-columns: 1fr auto; gap: 20px; align-items: start;">
                                    <div>
                                        <strong style="color: #333;">
                                            <i class="fas fa-home" style="color: #667eea;"></i> Address:
                                        </strong>
                                        <span style="margin-left: 10px;"><?php echo e($booking->address); ?></span>
                                        
                                        <?php if($booking->location): ?>
                                            <br><br>
                                            <strong style="color: #333;">
                                                <i class="fas fa-location-arrow" style="color: #667eea;"></i> GPS Location:
                                            </strong>
                                            <span style="margin-left: 10px;"><?php echo e($booking->location); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div style="text-align: right; color: #666; font-size: 0.8rem;">
                                        <div>
                                            <i class="fas fa-clock"></i> 
                                            Booked: <?php echo e($booking->created_at->format('M d, Y \a\t H:i A')); ?>

                                        </div>
                                        <?php if($booking->created_at != $booking->updated_at): ?>
                                            <div style="margin-top: 5px;">
                                                <i class="fas fa-edit"></i> 
                                                Updated: <?php echo e($booking->updated_at->format('M d, Y \a\t H:i A')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <div style="margin-top: 20px;">
                <?php echo e($bookings->links()); ?>

            </div>
        <?php else: ?>
            <div style="text-align: center; padding: 40px; color: #666;">
                <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.5;"></i>
                <h3>No Pending Orders</h3>
                <p>All caught up! No pending orders at the moment.</p>
                <div style="margin-top: 20px;">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary">
                        <i class="fas fa-tachometer-alt"></i> Back to Dashboard
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Stats Card -->
<?php if($bookings->count() > 0): ?>
<div class="content-card" style="margin-top: 30px;">
    <div class="card-header">
        <h3><i class="fas fa-chart-bar"></i> Quick Actions</h3>
    </div>
    <div class="card-body">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
            <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <div style="font-size: 2rem; color: #ffc107; margin-bottom: 10px;">
                    <i class="fas fa-clock"></i>
                </div>
                <div style="font-size: 1.5rem; font-weight: bold; color: #333;"><?php echo e($bookings->total()); ?></div>
                <div style="color: #666; font-size: 0.9rem;">Total Pending</div>
            </div>
            
            <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <div style="font-size: 2rem; color: #17a2b8; margin-bottom: 10px;">
                    <i class="fas fa-map-marked-alt"></i>
                </div>
                <div style="font-size: 1.5rem; font-weight: bold; color: #333;">
                    <?php echo e($bookings->whereNotNull('location')->count()); ?>

                </div>
                <div style="color: #666; font-size: 0.9rem;">With GPS Location</div>
            </div>
            
            <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <div style="font-size: 2rem; color: #28a745; margin-bottom: 10px;">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <div style="font-size: 1.5rem; font-weight: bold; color: #333;">
                 <?php echo e($bookings->filter(fn($booking) => $booking->created_at->isToday())->count()); ?>

                </div>
                <div style="color: #666; font-size: 0.9rem;">Today's Bookings</div>
            </div>
            
            <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <div style="font-size: 2rem; color: #667eea; margin-bottom: 10px;">
                    <i class="fas fa-tools"></i>
                </div>
                <div style="font-size: 1.5rem; font-weight: bold; color: #333;">
                    <?php echo e($bookings->whereNotNull('service')->count()); ?>

                </div>
                <div style="color: #666; font-size: 0.9rem;">Service Specified</div>
            </div>
        </div>
        
        <div style="margin-top: 30px; text-align: center;">
            <button class="btn btn-success" onclick="approveAllVisible()" style="margin-right: 10px;">
                <i class="fas fa-check-double"></i> Approve All Visible
            </button>
            <button class="btn btn-primary" onclick="refreshPage()">
                <i class="fas fa-sync-alt"></i> Refresh Page
            </button>
        </div>
    </div>
</div>
<!-- Approve Booking Modal -->
<div id="approveModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000;">
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; border-radius: 15px; width: 90%; max-width: 500px; max-height: 90%; overflow-y: auto;">
        <div style="padding: 20px; border-bottom: 1px solid #eee;">
            <h3 style="margin: 0; color: #333;">
                <i class="fas fa-check-circle"></i> Approve Booking
            </h3>
            <button onclick="closeApproveModal()" style="position: absolute; right: 15px; top: 15px; background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
        </div>
        <div id="approveModalContent" style="padding: 20px;">
            <form id="approveForm" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="mechanic_id">Assign Mechanic</label>
                    <select name="mechanic_id" id="mechanic_id" class="form-control" required>
                        <option value="">Select Mechanic</option>
                        <?php $__currentLoopData = App\Models\Mechanic::active()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mechanic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mechanic->id); ?>"><?php echo e($mechanic->name); ?> (<?php echo e($mechanic->phone); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div style="text-align: center; margin-top: 20px;">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check"></i> Approve Booking
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeApproveModal()" style="margin-left: 10px;">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Function to approve all visible bookings
function approveAllVisible() {
    if (confirm('Are you sure you want to approve all visible pending orders? This action cannot be undone.')) {
        const forms = document.querySelectorAll('form[action*="/approve"]');
        let count = 0;
        
        forms.forEach(form => {
            setTimeout(() => {
                form.submit();
            }, count * 500); // Stagger submissions by 500ms
            count++;
        });
    }
}

// Function to refresh page
function refreshPage() {
    window.location.reload();
}

// Auto-refresh functionality
let autoRefreshInterval;
let autoRefreshEnabled = false;

function toggleAutoRefresh() {
    if (autoRefreshEnabled) {
        clearInterval(autoRefreshInterval);
        autoRefreshEnabled = false;
        document.getElementById('autoRefreshBtn').innerHTML = '<i class="fas fa-play"></i> Enable Auto-Refresh';
    } else {
        autoRefreshInterval = setInterval(() => {
            window.location.reload();
        }, 30000); // Refresh every 30 seconds
        autoRefreshEnabled = true;
        document.getElementById('autoRefreshBtn').innerHTML = '<i class="fas fa-pause"></i> Disable Auto-Refresh';
    }
}

// Add keyboard shortcuts
document.addEventListener('keydown', function(event) {
    // Ctrl + R for refresh
    if (event.ctrlKey && event.key === 'r') {
        event.preventDefault();
        refreshPage();
    }
    
    // Ctrl + A for approve all (with additional confirmation)
    if (event.ctrlKey && event.key === 'a' && event.shiftKey) {
        event.preventDefault();
        approveAllVisible();
    }
});

// Add tooltips for better UX
document.addEventListener('DOMContentLoaded', function() {
    // Add loading state to buttons when clicked
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            if (this.type === 'submit') {
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                this.disabled = true;
                
                // Re-enable after 3 seconds (in case of error)
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                }, 3000);
            }
        });
    });
});

// Highlight rows on hover for better visibility
document.addEventListener('DOMContentLoaded', function() {
    const rows = document.querySelectorAll('tbody tr');
    rows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.backgroundColor = '#f0f8ff';
            this.style.transform = 'scale(1.01)';
            this.style.transition = 'all 0.2s ease';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.backgroundColor = '';
            this.style.transform = 'scale(1)';
        });
    });
});
let currentBookingId = null;

function showApproveModal(bookingId) {
    currentBookingId = bookingId;
    document.getElementById('approveForm').action = `/admin/bookings/${bookingId}/approve`;
    document.getElementById('approveModal').style.display = 'block';
}

function closeApproveModal() {
    document.getElementById('approveModal').style.display = 'none';
    currentBookingId = null;
}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/mechanic-booking/resources/views/admin/pending-orders.blade.php ENDPATH**/ ?>