<?php $__env->startSection('title', 'Add New Mechanic'); ?>

<?php $__env->startSection('content'); ?>
<div class="header">
    <h1><i class="fas fa-user-plus"></i> Add New Mechanic</h1>
    <a href="<?php echo e(route('admin.mechanics.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Back to Mechanics
    </a>
</div>

<div class="content-card">
    <div class="card-header">
        <h3><i class="fas fa-user-cog"></i> Mechanic Details</h3>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.mechanics.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" name="phone" id="phone" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Save Mechanic
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/mechanic-booking/resources/views/admin/mechanics/create.blade.php ENDPATH**/ ?>