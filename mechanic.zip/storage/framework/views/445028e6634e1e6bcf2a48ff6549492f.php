<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="header">
    <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
    <p>Welcome to AC Repair Service Admin Panel</p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon" style="color: #667eea;">
            <i class="fas fa-calendar-day"></i>
        </div>
        <div class="stat-number" style="color: #667eea;"><?php echo e($todayOrders); ?></div>
        <div class="stat-label">Orders Today</div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="color: #764ba2;">
            <i class="fas fa-calendar-alt"></i>
        </div>
        <div class="stat-number" style="color: #764ba2;"><?php echo e($monthOrders); ?></div>
        <div class="stat-label">Orders This Month</div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="color: #ffc107;">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-number" style="color: #ffc107;"><?php echo e($pendingOrders); ?></div>
        <div class="stat-label">Pending Orders</div>
    </div>

    <div class="stat-card">
        <div class="stat-icon" style="color: #28a745;">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-number" style="color: #28a745;"><?php echo e($completedOrders); ?></div>
        <div class="stat-label">Completed Orders</div>
    </div>
</div>

<div class="content-card">
    <div class="card-header">
        <h3><i class="fas fa-chart-line"></i> Quick Overview</h3>
    </div>
    <div class="card-body">
        <p>Your AC repair service is running smoothly! Here's what's happening:</p>
        <ul style="margin: 20px 0; padding-left: 20px;">
            <li>You have <strong><?php echo e($pendingOrders); ?></strong> orders waiting for approval</li>
            <li><strong><?php echo e($completedOrders); ?></strong> orders have been successfully completed</li>
            <li>Total of <strong><?php echo e($todayOrders); ?></strong> new orders received today</li>
        </ul>
        <div style="margin-top: 20px;">
            <a href="<?php echo e(route('admin.pending')); ?>" class="btn btn-primary">
                <i class="fas fa-eye"></i> View Pending Orders
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/mechanic_booking_website/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>